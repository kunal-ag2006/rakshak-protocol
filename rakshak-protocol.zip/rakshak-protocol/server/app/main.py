"""
FastAPI Main Application for Rakshak Protocol.
Provides RESTful APIs, WebSocket Live Stream, and Emergency Operations Center (EOC) Dashboard.
"""

import asyncio
from dataclasses import asdict
import json
import time
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from server.app.config import settings
from server.app.drone_router import Coordinates, drone_router
from server.app.evidence_vault import evidence_vault
from server.app.models import IncidentSummary, TelemetryFrame, ThreatSeverity, dump_model
from server.app.mqtt_broker import incident_manager

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Rakshak Protocol: Zero-Click SOS, Autonomous Drone Dispatch, and Evidence Vault."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Active WebSocket connections
active_connections: List[WebSocket] = []


def ws_broadcast_handler(event_payload: Dict[str, Any]):
    """Push updates to all active EOC dashboard browser sessions."""
    dead_sockets = []
    message = json.dumps(event_payload)
    for ws in list(active_connections):
        try:
            asyncio.create_task(ws.send_text(message))
        except Exception:
            dead_sockets.append(ws)

    for dead in dead_sockets:
        if dead in active_connections:
            active_connections.remove(dead)


incident_manager.register_broadcast_listener(ws_broadcast_handler)


@app.get("/health")
def health_check():
    return {"status": "HEALTHY", "service": "Rakshak-Protocol-Engine", "version": settings.VERSION}


@app.get(f"{settings.API_PREFIX}/incidents", response_model=List[IncidentSummary])
def get_all_incidents():
    """Retrieve list of all active and recorded emergency incidents."""
    return list(incident_manager.active_incidents.values())


@app.get(f"{settings.API_PREFIX}/incidents/{{incident_id}}")
def get_incident_details(incident_id: str):
    """Retrieve detailed telemetry, drone status, and summary for an incident."""
    if incident_id not in incident_manager.active_incidents:
        raise HTTPException(status_code=404, detail="Incident ID not found")

    incident = incident_manager.active_incidents[incident_id]
    telemetry_stream = incident_manager.telemetry_history.get(incident_id, [])
    drone = drone_router.drones_telemetry.get(incident.assigned_drone_id) if incident.assigned_drone_id else None
    verified, msg = evidence_vault.verify_chain_integrity(incident_id)

    return {
        "incident": dump_model(incident),
        "telemetry_stream": [dump_model(t) for t in telemetry_stream],
        "assigned_drone": dump_model(drone) if drone else None,
        "evidence_chain_length": len(evidence_vault.get_chain(incident_id)),
        "evidence_integrity_verified": verified,
        "evidence_verification_report": msg,
    }


@app.get(f"{settings.API_PREFIX}/incidents/{{incident_id}}/evidence-ledger")
def get_evidence_ledger(incident_id: str):
    """Inspect full cryptographic append-only evidence blocks with SHA-256 hashes."""
    chain = evidence_vault.get_chain(incident_id)
    is_valid, report = evidence_vault.verify_chain_integrity(incident_id)
    return {
        "incident_id": incident_id,
        "block_count": len(chain),
        "chain_integrity_valid": is_valid,
        "audit_report": report,
        "blocks": [dump_model(b) for b in chain],
    }


@app.get(f"{settings.API_PREFIX}/drones/stations")
def list_drone_stations():
    """List all cell-tower drone base stations and dock status."""
    return {
        "stations": [dump_model(s) for s in drone_router.stations.values()],
        "drones": [dump_model(d) for d in drone_router.drones_telemetry.values()],
    }


@app.post(f"{settings.API_PREFIX}/sos/trigger")
def trigger_sos_manually(frame: TelemetryFrame):
    """Inject/Ingest an SOS telemetry packet (from edge device or manual trigger)."""
    result = incident_manager.ingest_telemetry_frame(frame)
    return result


@app.post(f"{settings.API_PREFIX}/drone/step")
def step_drone_simulation(drone_id: str, dt_seconds: float = 1.0):
    """Step drone simulation forwards."""
    updated = drone_router.simulate_drone_step(drone_id, dt_seconds)
    if updated:
        incident_manager.broadcast_event("DRONE_TELEMETRY_UPDATE", dump_model(updated))
        return dump_model(updated)
    raise HTTPException(status_code=404, detail="Drone ID not found")


@app.websocket("/ws/emergency-feed")
async def websocket_emergency_feed(websocket: WebSocket):
    """Real-time bidirectional WebSocket stream for EOC Dispatch Console."""
    await websocket.accept()
    active_connections.append(websocket)
    try:
        # Send initial snapshot
        snapshot = {
            "event": "INITIAL_STATE",
            "incidents": [dump_model(i) for i in incident_manager.active_incidents.values()],
            "drones": [dump_model(d) for d in drone_router.drones_telemetry.values()],
            "stations": [dump_model(s) for s in drone_router.stations.values()],
        }
        await websocket.send_text(json.dumps(snapshot))

        while True:
            data = await websocket.receive_text()
            try:
                cmd = json.loads(data)
                if cmd.get("action") == "PING":
                    await websocket.send_text(json.dumps({"event": "PONG", "timestamp": time.time()}))
            except Exception:
                pass
    except WebSocketDisconnect:
        if websocket in active_connections:
            active_connections.remove(websocket)


@app.get("/", response_class=HTMLResponse)
def serve_dashboard():
    """Serve the web-based Emergency Response Operations Center dashboard."""
    try:
        with open("/working_dir/c_9128f2d0caca99c9/rakshak-protocol/server/templates/index.html", "r") as f:
            return f.read()
    except Exception as e:
        return f"<h1>Rakshak Protocol EOC Console</h1><p>API is active. Error loading template: {e}</p>"
