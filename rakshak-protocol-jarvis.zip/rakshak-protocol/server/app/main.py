"""
Rakshak Protocol - Stark Classified JARVIS Command System & API Server
Author: TransparentGov Core Engineering // Kunal
License: MIT
"""

import asyncio
from dataclasses import asdict
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from server.app.config import settings
from server.app.drone_router import Coordinates, drone_router
from server.app.evidence_vault import evidence_vault
from server.app.models import IncidentSummary, TelemetryFrame, ThreatSeverity, dump_model
from server.app.mqtt_broker import incident_manager

app = FastAPI(
    title="Rakshak Protocol",
    version="1.0.0",
    description="Zero-Click Emergency SOS, Autonomous Drone Dispatch, and Evidence Vault"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Active WebSocket connections for live HUD sessions
active_connections: List[WebSocket] = []


def ws_broadcast_handler(event_payload: Dict[str, Any]):
    """Push real-time updates to all active operator consoles."""
    dead_sockets = []
    message = json.dumps(event_payload)
    for ws in list(active_connections):
        try:
            asyncio.create_task(ws.send_text(message))
        except Exception:
            dead_sockets.append(ws)

    for dead in dead_sockets:
        if dead in active_connections:
            active_connections.remove(dead)


incident_manager.register_broadcast_listener(ws_broadcast_handler)


@app.get("/health")
def health_check():
    return {"status": "HEALTHY", "service": "rakshak-protocol-engine", "version": "1.0.0"}


@app.get(f"{settings.API_PREFIX}/incidents", response_model=List[IncidentSummary])
def get_all_incidents():
    return list(incident_manager.active_incidents.values())


@app.get(f"{settings.API_PREFIX}/incidents/{{incident_id}}")
def get_incident_details(incident_id: str):
    if incident_id not in incident_manager.active_incidents:
        raise HTTPException(status_code=404, detail="Incident not found")

    incident = incident_manager.active_incidents[incident_id]
    telemetry_stream = incident_manager.telemetry_history.get(incident_id, [])
    drone = drone_router.drones_telemetry.get(incident.assigned_drone_id) if incident.assigned_drone_id else None
    verified, msg = evidence_vault.verify_chain_integrity(incident_id)

    return {
        "incident": dump_model(incident),
        "telemetry_stream": [dump_model(t) for t in telemetry_stream],
        "assigned_drone": dump_model(drone) if drone else None,
        "evidence_chain_length": len(evidence_vault.get_chain(incident_id)),
        "evidence_integrity_verified": verified,
        "evidence_verification_report": msg,
    }


@app.get(f"{settings.API_PREFIX}/incidents/{{incident_id}}/evidence-ledger")
def get_evidence_ledger(incident_id: str):
    chain = evidence_vault.get_chain(incident_id)
    is_valid, report = evidence_vault.verify_chain_integrity(incident_id)
    return {
        "incident_id": incident_id,
        "block_count": len(chain),
        "chain_integrity_valid": is_valid,
        "audit_report": report,
        "blocks": [dump_model(b) for b in chain],
    }


@app.get(f"{settings.API_PREFIX}/drones/stations")
def list_drone_stations():
    return {
        "stations": [dump_model(s) for s in drone_router.stations.values()],
        "drones": [dump_model(d) for d in drone_router.drones_telemetry.values()],
    }


@app.post(f"{settings.API_PREFIX}/sos/trigger")
def trigger_sos_manually(frame: TelemetryFrame):
    result = incident_manager.ingest_telemetry_frame(frame)
    return result


@app.post(f"{settings.API_PREFIX}/drone/step")
def step_drone_simulation(drone_id: str, dt_seconds: float = 1.0):
    updated = drone_router.simulate_drone_step(drone_id, dt_seconds)
    if updated:
        incident_manager.broadcast_event("DRONE_TELEMETRY_UPDATE", dump_model(updated))
        return dump_model(updated)
    raise HTTPException(status_code=404, detail="Drone not found")


@app.websocket("/ws/emergency-feed")
async def websocket_emergency_feed(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    try:
        snapshot = {
            "event": "INITIAL_STATE",
            "incidents": [dump_model(i) for i in incident_manager.active_incidents.values()],
            "drones": [dump_model(d) for d in drone_router.drones_telemetry.values()],
            "stations": [dump_model(s) for s in drone_router.stations.values()],
        }
        await websocket.send_text(json.dumps(snapshot))

        while True:
            data = await websocket.receive_text()
            try:
                cmd = json.loads(data)
                if cmd.get("action") == "PING":
                    await websocket.send_text(json.dumps({"event": "PONG", "timestamp": time.time()}))
            except Exception:
                pass
    except WebSocketDisconnect:
        if websocket in active_connections:
            active_connections.remove(websocket)


EMBEDDED_HTML_DASHBOARD = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STARK // J.A.R.V.I.S. // RAKSHAK PROTOCOL [CLASSIFIED LEVEL-5]</title>
    <!-- Lenis Smooth Scroll -->
    <script src="https://unpkg.com/lenis@1.1.18/dist/lenis.min.js"></script>
    <!-- Anime.js Engine -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.2/anime.min.js"></script>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;500;600;700&family=Orbitron:wght@500;700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        :root {
            --jarvis-gold: #ffaa00;
            --jarvis-orange: #ff6600;
            --jarvis-cyan: #00e5ff;
            --jarvis-red: #ff1744;
            --jarvis-green: #00e676;
            --holo-dim: rgba(0, 229, 255, 0.12);
            --holo-border: rgba(0, 229, 255, 0.35);
            --hud-bg: rgba(2, 6, 14, 0.85);
            --bg-void: #010308;
            --text-main: #d1e4ff;
            --text-dim: #5c7499;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; }
        
        html.lenis { height: auto; }
        .lenis.lenis-smooth { scroll-behavior: auto; }
        .lenis.lenis-smooth [data-lenis-prevent] { overscroll-behavior: contain; }

        body {
            background-color: var(--bg-void);
            background-image: 
                radial-gradient(circle at 50% 30%, rgba(0, 229, 255, 0.05) 0%, transparent 70%),
                radial-gradient(circle at 80% 80%, rgba(255, 170, 0, 0.03) 0%, transparent 60%),
                linear-gradient(rgba(0, 229, 255, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 229, 255, 0.03) 1px, transparent 1px);
            background-size: 100% 100%, 100% 100%, 40px 40px, 40px 40px;
            color: var(--text-main);
            font-family: 'Chakra Petch', sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Classified Watermark Background */
        .watermark-banner {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-25deg);
            font-family: 'Orbitron', sans-serif;
            font-size: 4.5rem;
            font-weight: 900;
            color: rgba(255, 23, 68, 0.03);
            letter-spacing: 12px;
            pointer-events: none;
            white-space: nowrap;
            z-index: 0;
        }

        /* Top JARVIS Classified Header */
        header {
            background: rgba(1, 4, 10, 0.92);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--holo-border);
            padding: 10px 28px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 0 30px rgba(0, 229, 255, 0.08);
        }

        .jarvis-brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .arc-reactor-mini {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: 2px solid var(--jarvis-cyan);
            box-shadow: 0 0 15px var(--jarvis-cyan), inset 0 0 10px var(--jarvis-cyan);
            position: relative;
            animation: spinReactor 8s linear infinite;
        }
        .arc-reactor-mini::after {
            content: '';
            position: absolute;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            width: 10px; height: 10px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 0 10px #fff;
        }
        @keyframes spinReactor { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

        .brand-text {
            font-family: 'Orbitron', sans-serif;
            font-weight: 900;
            font-size: 1.25rem;
            letter-spacing: 3px;
            color: #fff;
            text-shadow: 0 0 12px var(--jarvis-cyan);
        }

        .clearance-badge {
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.72rem;
            padding: 4px 10px;
            border: 1px solid var(--jarvis-red);
            background: rgba(255, 23, 68, 0.1);
            color: var(--jarvis-red);
            font-weight: bold;
            letter-spacing: 1px;
        }

        /* Classified Telemetry Strip */
        .hud-ticker-strip {
            background: #02060e;
            border-bottom: 1px solid rgba(0, 229, 255, 0.15);
            padding: 6px 28px;
            display: flex;
            gap: 32px;
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.75rem;
            color: var(--text-dim);
            z-index: 10;
        }
        .ticker-val { color: var(--jarvis-cyan); font-weight: bold; }

        /* Main Holographic Layout */
        main {
            display: grid;
            grid-template-columns: 340px 1fr 340px;
            gap: 16px;
            padding: 16px 24px;
            flex: 1;
            position: relative;
            z-index: 10;
        }

        /* Iron Man Holographic HUD Cards */
        .hud-panel {
            background: var(--hud-bg);
            border: 1px solid var(--holo-border);
            border-radius: 2px;
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 14px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6), inset 0 0 20px rgba(0, 229, 255, 0.03);
            backdrop-filter: blur(14px);
            position: relative;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        /* Tactical HUD Corner Brackets */
        .hud-panel::before {
            content: '';
            position: absolute;
            top: -1px; left: -1px;
            width: 14px; height: 14px;
            border-top: 2px solid var(--jarvis-cyan);
            border-left: 2px solid var(--jarvis-cyan);
        }
        .hud-panel::after {
            content: '';
            position: absolute;
            bottom: -1px; right: -1px;
            width: 14px; height: 14px;
            border-bottom: 2px solid var(--jarvis-cyan);
            border-right: 2px solid var(--jarvis-cyan);
        }

        .hud-panel-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 2px;
            color: #94b8e6;
            text-transform: uppercase;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(0, 229, 255, 0.15);
            padding-bottom: 6px;
        }

        /* Metric Grid & Cards */
        .grid-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .holo-card {
            background: rgba(4, 12, 24, 0.7);
            border: 1px solid rgba(0, 229, 255, 0.2);
            padding: 10px 12px;
            position: relative;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .holo-card.danger {
            border-color: var(--jarvis-red);
            background: rgba(255, 23, 68, 0.08);
            box-shadow: 0 0 15px rgba(255, 23, 68, 0.25);
        }
        .holo-label {
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.68rem;
            color: var(--text-dim);
            letter-spacing: 1px;
        }
        .holo-value {
            font-family: 'Orbitron', monospace;
            font-size: 1.35rem;
            font-weight: 800;
            color: #fff;
            margin-top: 3px;
        }

        /* Center JARVIS Tactical Radar Hologram */
        .tactical-holo-viewport {
            position: relative;
            background: radial-gradient(circle at 50% 50%, #030d1c 0%, #01040a 100%);
            border: 1px solid var(--holo-border);
            height: 400px;
            overflow: hidden;
            box-shadow: inset 0 0 60px rgba(0, 229, 255, 0.1);
        }
        #jarvisCanvas { width: 100%; height: 100%; display: block; }

        .hud-reticle-overlay {
            position: absolute;
            top: 14px; left: 14px;
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.74rem;
            color: var(--jarvis-cyan);
            background: rgba(1, 5, 12, 0.75);
            padding: 6px 12px;
            border-left: 2px solid var(--jarvis-cyan);
            line-height: 1.4;
            pointer-events: none;
        }

        /* Waveform Containers */
        .holo-wave {
            width: 100%;
            height: 48px;
            background: #02050b;
            border: 1px solid rgba(0, 229, 255, 0.15);
        }

        /* JARVIS Tactical Holographic Buttons */
        .btn-jarvis {
            font-family: 'Orbitron', sans-serif;
            font-size: 0.75rem;
            font-weight: 800;
            letter-spacing: 1.5px;
            padding: 12px 16px;
            border: 1px solid transparent;
            cursor: pointer;
            text-transform: uppercase;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
            position: relative;
        }
        .btn-jarvis-red {
            background: linear-gradient(135deg, #ff1744 0%, #990022 100%);
            color: #fff;
            border-color: #ff5277;
            box-shadow: 0 0 20px rgba(255, 23, 68, 0.4);
        }
        .btn-jarvis-red:hover {
            box-shadow: 0 0 35px rgba(255, 23, 68, 0.7);
            transform: translateY(-2px);
        }
        .btn-jarvis-cyan {
            background: rgba(0, 229, 255, 0.1);
            color: var(--jarvis-cyan);
            border-color: var(--jarvis-cyan);
            box-shadow: 0 0 15px rgba(0, 229, 255, 0.15);
        }
        .btn-jarvis-cyan:hover {
            background: var(--jarvis-cyan);
            color: #000;
            box-shadow: 0 0 25px var(--jarvis-cyan);
            transform: translateY(-2px);
        }
        .btn-jarvis-gold {
            background: rgba(255, 170, 0, 0.1);
            color: var(--jarvis-gold);
            border-color: var(--jarvis-gold);
        }
        .btn-jarvis-gold:hover {
            background: var(--jarvis-gold);
            color: #000;
            box-shadow: 0 0 25px var(--jarvis-gold);
            transform: translateY(-2px);
        }

        /* Evidence Ledger Terminal */
        .terminal-vault {
            background: #010408;
            border: 1px solid rgba(0, 229, 255, 0.15);
            padding: 10px;
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.72rem;
            color: #38bdf8;
            height: 250px;
            overflow-y: auto;
        }
        .terminal-row {
            margin-bottom: 8px;
            border-bottom: 1px dashed rgba(0, 229, 255, 0.15);
            padding-bottom: 4px;
        }
        .hash-gold { color: var(--jarvis-gold); word-break: break-all; }

        footer {
            background: #010307;
            border-top: 1px solid rgba(0, 229, 255, 0.15);
            padding: 8px 28px;
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.72rem;
            color: var(--text-dim);
            display: flex;
            justify-content: space-between;
            z-index: 10;
        }
    </style>
</head>
<body>
    <div class="watermark-banner">TOP SECRET // CLASSIFIED // LEVEL-5</div>

    <header>
        <div class="jarvis-brand">
            <div class="arc-reactor-mini"></div>
            <div>
                <div class="brand-text">J.A.R.V.I.S. // RAKSHAK PROTOCOL</div>
                <div style="font-size: 0.65rem; color: var(--jarvis-cyan); font-family: 'Share Tech Mono';">AUTONOMOUS URBAN CIVIC DEFENSE & DRONE TRIAGE</div>
            </div>
        </div>
        <div style="display: flex; gap: 14px; align-items: center;">
            <div id="hudDefenseStatus" class="clearance-badge">CLEARANCE: LEVEL-5 // ARMED</div>
            <div style="font-family: 'Share Tech Mono'; font-size: 0.8rem; color: var(--text-dim);" id="clockDisplay">00:00:00 UTC</div>
        </div>
    </header>

    <div class="hud-ticker-strip">
        <div><strong>CORE TELEMETRY:</strong> <span class="ticker-val">MQTT TLS 1.3 // 256-BIT ENCRYPTED</span></div>
        <div><strong>WEARABLE BIOMETRICS:</strong> <span class="ticker-val" id="tickerBio">PPG OPTICAL ARMED</span></div>
        <div><strong>NEURAL AUDIO GUARD:</strong> <span class="ticker-val" id="tickerAudio">ACOUSTIC INFERENCE ACTIVE</span></div>
        <div><strong>STARK DRONE DOCK:</strong> <span class="ticker-val">CELL-TOWER #402 READY</span></div>
    </div>

    <main>
        <!-- LEFT PANEL: Wearable Telemetry & Acoustic Neural Guard -->
        <section class="hud-panel">
            <div class="hud-panel-title">
                <span>Citizen Biometrics (PPG/HRV)</span>
                <span id="badgeBioStatus" style="color: var(--jarvis-green); font-size: 0.72rem; font-family: 'Orbitron';">NOMINAL</span>
            </div>

            <div class="grid-2col">
                <div class="holo-card" id="cardHR">
                    <div class="holo-label">Heart Rate (HR)</div>
                    <div class="holo-value"><span id="valHR">72</span> <span style="font-size: 0.7rem; color: var(--text-dim);">BPM</span></div>
                </div>
                <div class="holo-card" id="cardHRV">
                    <div class="holo-label">HRV (RMSSD)</div>
                    <div class="holo-value"><span id="valHRV">48.2</span> <span style="font-size: 0.7rem; color: var(--text-dim);">ms</span></div>
                </div>
            </div>

            <div>
                <div class="holo-label" style="margin-bottom: 4px;">Dynamic Electrocardiogram (ECG)</div>
                <canvas id="ecgCanvas" class="holo-wave"></canvas>
            </div>

            <div class="hud-panel-title" style="margin-top: 6px;">
                <span>On-Device TinyML Acoustic Guard</span>
                <span id="badgeAudioStatus" style="color: var(--jarvis-cyan); font-size: 0.72rem; font-family: 'Orbitron';">LISTENING</span>
            </div>

            <div class="holo-card" id="cardAcoustic">
                <div class="holo-label">Neural Sound Classification</div>
                <div class="holo-value" style="font-size: 1.05rem;" id="valAcoustic">AMBIENT_NORMAL</div>
                <div class="holo-label" style="margin-top: 4px;">Confidence: <strong id="valConf" style="color: var(--jarvis-green);">94.8%</strong></div>
            </div>

            <div>
                <div class="holo-label" style="margin-bottom: 4px;">Acoustic Waveform Spectrogram</div>
                <canvas id="audioCanvas" class="holo-wave"></canvas>
            </div>

            <div class="hud-panel-title" style="margin-top: 6px;">
                <span>Stealth Mode Defense</span>
            </div>
            <div style="font-family: 'Share Tech Mono', monospace; font-size: 0.74rem; background: rgba(3, 8, 18, 0.8); border: 1px solid rgba(0, 229, 255, 0.15); padding: 8px; display: flex; flex-direction: column; gap: 4px;">
                <div>Citizen Phone Display: <strong id="valScreen" style="color: var(--jarvis-green);">UNLOCKED (NORMAL)</strong></div>
                <div>Silent Uplink: <strong id="valUplink" style="color: var(--text-dim);">STANDBY (0 B/s)</strong></div>
                <div>GPS Target: <strong style="color: var(--jarvis-cyan);">28.6139° N, 77.2090° E</strong></div>
            </div>
        </section>

        <!-- CENTER PANEL: JARVIS Tactical Radar Hologram -->
        <section class="hud-panel">
            <div class="hud-panel-title">
                <span>Stark Tactical Drone Radar // Sector 4</span>
                <span id="badgeDroneStatus" style="color: var(--jarvis-cyan); font-size: 0.72rem; font-family: 'Orbitron';">DOCKED READY</span>
            </div>

            <div class="tactical-holo-viewport">
                <canvas id="jarvisCanvas"></canvas>
                <div class="hud-reticle-overlay">
                    <div>GRID: <strong>DELHI-NCR // CELL-402</strong></div>
                    <div>STATUS: <span id="hudTargetStatus" style="color: var(--jarvis-green);">SURVEILLANCE_ACTIVE</span></div>
                    <div>AUTONOMOUS FLIGHT: <strong id="hudFlightStatus">IDLE_IN_DOCK</strong></div>
                </div>
            </div>

            <div class="grid-2col">
                <div class="holo-card">
                    <div class="holo-label">Cell Tower Station</div>
                    <div class="holo-value" style="font-size: 0.95rem;">AIRTEL TOWER #402</div>
                </div>
                <div class="holo-card danger" id="cardETA">
                    <div class="holo-label">Drone Flight ETA to Target</div>
                    <div class="holo-value" id="valETA">0.0 <span style="font-size: 0.75rem;">sec</span></div>
                </div>
                <div class="holo-card">
                    <div class="holo-label">Airspeed & Altitude</div>
                    <div class="holo-value" style="font-size: 0.95rem;" id="valSpeedAlt">0 km/h | 0m AGL</div>
                </div>
                <div class="holo-card">
                    <div class="holo-label">Deterrence Payload</div>
                    <div class="holo-value" style="font-size: 0.85rem;" id="valDeterrence">HIGH-LUMEN STROBES ARMED</div>
                </div>
            </div>

            <div class="hud-panel-title" style="margin-top: 4px;">
                <span>Tactical Scenario Operations</span>
            </div>
            <div style="display: grid; grid-template-columns: 1.4fr 1fr 1fr; gap: 10px;">
                <button class="btn-jarvis btn-jarvis-red" onclick="triggerAmbush()">🚨 LAUNCH STEALTH AMBUSH</button>
                <button class="btn-jarvis btn-jarvis-gold" onclick="trigger3sButton()">⚡ 3s POWER OVERRIDE</button>
                <button class="btn-jarvis btn-jarvis-cyan" onclick="resetSystem()">🔄 RESET BASELINE</button>
            </div>
        </section>

        <!-- RIGHT PANEL: Cryptographic SHA-256 Court Ledger -->
        <section class="hud-panel">
            <div class="hud-panel-title">
                <span>Cryptographic Evidence Vault</span>
                <span style="color: var(--jarvis-gold); font-size: 0.72rem; font-family: 'Orbitron';">SHA-256 CHAIN</span>
            </div>
            <div style="font-family: 'Share Tech Mono'; font-size: 0.74rem; color: var(--text-dim);">
                Append-only tamper-proof ledger for judicial chain-of-custody.
            </div>
            <div class="terminal-vault" id="ledgerLogs">
                <div class="terminal-row">
                    [GENESIS BLOCK #0] Initialized.<br>
                    <span class="hash-gold">PrevHash: 0000000000000000000000000000000000000000000000000000000000000000</span>
                </div>
            </div>
            <button class="btn-jarvis btn-jarvis-cyan" onclick="verifyChain()">🔒 AUDIT CRYPTOGRAPHIC INTEGRITY</button>
        </section>
    </main>

    <footer>
        <div>SHORTCUTS: <code>[SPACE]</code> Trigger Ambush &nbsp;|&nbsp; <code>[R]</code> Reset Baseline &nbsp;|&nbsp; <code>[V]</code> Verify Ledger</div>
        <div>STARK CIVIC DEFENSE OS // RAKSHAK PROTOCOL v3.0 [JARVIS CLASSIFIED ENGINE]</div>
    </footer>

    <!-- Audio Synthesizer & Canvas Radar Engine -->
    <script>
        // 1. Initialize Lenis Smooth Scroll
        const lenis = new Lenis({
            duration: 1.2,
            easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            orientation: 'vertical',
            smoothWheel: true
        });
        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }
        requestAnimationFrame(raf);

        // 2. Web Audio API Synthesizer (JARVIS Holographic Sound FX)
        const audioCtxObj = new (window.AudioContext || window.webkitAudioContext)();
        function playJarvisBeep(freq = 880, duration = 0.08, type = 'sine') {
            try {
                if (audioCtxObj.state === 'suspended') audioCtxObj.resume();
                const osc = audioCtxObj.createOscillator();
                const gain = audioCtxObj.createGain();
                osc.type = type;
                osc.frequency.setValueAtTime(freq, audioCtxObj.currentTime);
                gain.gain.setValueAtTime(0.08, audioCtxObj.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.0001, audioCtxObj.currentTime + duration);
                osc.connect(gain);
                gain.connect(audioCtxObj.destination);
                osc.start();
                osc.stop(audioCtxObj.currentTime + duration);
            } catch(e){}
        }

        // Clock Update
        setInterval(() => {
            document.getElementById('clockDisplay').innerText = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
        }, 1000);

        const canvas = document.getElementById('jarvisCanvas');
        const ctx = canvas.getContext('2d');
        const ecgCanvas = document.getElementById('ecgCanvas');
        const ecgCtx = ecgCanvas.getContext('2d');
        const audioCanvas = document.getElementById('audioCanvas');
        const audioCtx = audioCanvas.getContext('2d');

        function resize() {
            canvas.width = canvas.parentElement.clientWidth;
            canvas.height = canvas.parentElement.clientHeight;
            ecgCanvas.width = ecgCanvas.clientWidth;
            ecgCanvas.height = ecgCanvas.clientHeight;
            audioCanvas.width = audioCanvas.clientWidth;
            audioCanvas.height = audioCanvas.clientHeight;
        }
        window.addEventListener('resize', resize);
        resize();

        let state = 'NORMAL';
        let currentIncidentId = 'INC-JARVIS-001';
        let seq = 0;
        let radarAngle = 0;
        let arcReactorPulse = 0;

        const tower = { x: 0.18, y: 0.35 };
        const guy = { x: 0.82, y: 0.68, shockwaveRadius: 0 };
        const drone = { x: tower.x, y: tower.y, rotorAngle: 0, active: false, strobeFlash: false };

        let ecgPhase = 0;
        let audioPhase = 0;

        function addLedgerEntry(blockIndex, incidentId, hash, prevHash) {
            const box = document.getElementById("ledgerLogs");
            const entry = document.createElement("div");
            entry.className = "terminal-row";
            entry.innerHTML = `[BLOCK #${blockIndex}] Incident: ${incidentId}<br>
                Prev: <span class="hash-gold">${prevHash.substring(0, 22)}...</span><br>
                Hash: <span class="hash-gold">${hash.substring(0, 30)}...</span>`;
            box.appendChild(entry);
            box.scrollTop = box.scrollHeight;

            anime({
                targets: entry,
                translateX: [-25, 0],
                opacity: [0, 1],
                duration: 450,
                easing: 'easeOutExpo'
            });
        }

        // ==============================================
        //  JARVIS CANVAS RADAR RENDER (60 FPS)
        // ==============================================
        function drawJarvisRadar() {
            const w = canvas.width;
            const h = canvas.height;
            ctx.clearRect(0, 0, w, h);

            // 1. Tactical Grid Lines
            ctx.strokeStyle = 'rgba(0, 229, 255, 0.08)';
            ctx.lineWidth = 1;
            const step = 40;
            for (let x = 0; x < w; x += step) {
                ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
            }
            for (let y = 0; y < h; y += step) {
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
            }

            // 2. Concentric Hologram Rings & Range Markers
            const cx = tower.x * w;
            const cy = tower.y * h;
            arcReactorPulse += 0.02;

            [60, 130, 230, 350].forEach((r, idx) => {
                ctx.beginPath();
                ctx.arc(cx, cy, r, 0, Math.PI * 2);
                ctx.strokeStyle = (idx === 1 || idx === 3) ? 'rgba(0, 229, 255, 0.28)' : 'rgba(0, 229, 255, 0.12)';
                ctx.setLineDash(idx % 2 === 0 ? [3, 8] : []);
                ctx.stroke();
                ctx.setLineDash([]);

                ctx.fillStyle = 'rgba(0, 229, 255, 0.45)';
                ctx.font = '10px "Share Tech Mono"';
                ctx.fillText(`SECTOR_${(idx + 1) * 500}M`, cx + r + 4, cy - 4);
            });

            // 3. Rotating Holographic Arc Sweep
            radarAngle += 0.028;
            ctx.save();
            ctx.translate(cx, cy);
            ctx.rotate(radarAngle);
            const sweep = ctx.createRadialGradient(0, 0, 0, 0, 0, 350);
            sweep.addColorStop(0, 'rgba(0, 229, 255, 0.35)');
            sweep.addColorStop(1, 'rgba(0, 229, 255, 0.0)');
            ctx.fillStyle = sweep;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.arc(0, 0, 350, 0, Math.PI / 4);
            ctx.closePath();
            ctx.fill();
            ctx.restore();

            // 4. Tower Docking Node (Cell Tower #402)
            ctx.fillStyle = '#00e5ff';
            ctx.beginPath(); ctx.arc(cx, cy, 7, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = 'rgba(0, 229, 255, 0.6)';
            ctx.lineWidth = 4;
            ctx.stroke();
            ctx.font = 'bold 11px "Orbitron"';
            ctx.fillStyle = '#7dd3fc';
            ctx.fillText('📡 STARK DOCK #402', cx - 55, cy - 14);

            // 5. Citizen / Guy Rendering
            const gx = guy.x * w;
            const gy = guy.y * h;

            if (state === 'NORMAL') {
                guy.x += (Math.random() - 0.5) * 0.0003;
                guy.y += (Math.random() - 0.5) * 0.0003;
                guy.x = Math.max(0.5, Math.min(0.9, guy.x));
                guy.y = Math.max(0.4, Math.min(0.85, guy.y));
            } else {
                // Expanding Red Attack Waves
                guy.shockwaveRadius = (guy.shockwaveRadius + 0.9) % 45;
                ctx.beginPath();
                ctx.arc(gx, gy, guy.shockwaveRadius, 0, Math.PI * 2);
                ctx.strokeStyle = `rgba(255, 23, 68, ${1 - guy.shockwaveRadius / 45})`;
                ctx.lineWidth = 2.5;
                ctx.stroke();
            }

            // Citizen Avatar
            ctx.fillStyle = (state === 'NORMAL') ? '#00e676' : '#ff1744';
            ctx.beginPath(); ctx.arc(gx, gy, 8, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
            ctx.font = 'bold 11px "Orbitron"';
            ctx.fillStyle = (state === 'NORMAL') ? '#69f0ae' : '#ff1744';
            ctx.fillText((state === 'NORMAL') ? '🚶 CITIZEN [NOMINAL]' : '🚨 VICTIM [STEALTH SOS]', gx - 65, gy + 22);

            // 6. Drone Quadcopter & Spotlight
            drone.rotorAngle += 0.5;
            const dx = drone.x * w;
            const dy = drone.y * h;

            if (drone.active) {
                // Trajectory vector line
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.lineTo(dx, dy);
                ctx.lineTo(gx, gy);
                ctx.strokeStyle = 'rgba(0, 229, 255, 0.5)';
                ctx.lineWidth = 2;
                ctx.setLineDash([5, 5]);
                ctx.stroke();
                ctx.setLineDash([]);

                // Ground Spotlight Cone
                ctx.save();
                const cone = ctx.createRadialGradient(dx, dy, 4, dx, dy, 95);
                cone.addColorStop(0, 'rgba(0, 229, 255, 0.45)');
                cone.addColorStop(1, 'rgba(0, 229, 255, 0.0)');
                ctx.fillStyle = cone;
                ctx.beginPath(); ctx.arc(dx, dy, 95, 0, Math.PI * 2); ctx.fill();
                ctx.restore();
            }

            // Drone Quadcopter Avatar
            ctx.save();
            ctx.translate(dx, dy);
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-14, -14); ctx.lineTo(14, 14);
            ctx.moveTo(14, -14); ctx.lineTo(-14, 14);
            ctx.stroke();

            // 4 Neon Rotor Blades
            [ [-14, -14], [14, -14], [-14, 14], [14, 14] ].forEach(([rx, ry]) => {
                ctx.fillStyle = 'rgba(0, 229, 255, 0.7)';
                ctx.beginPath(); ctx.arc(rx, ry, 7, 0, Math.PI * 2); ctx.fill();
                ctx.strokeStyle = '#00e5ff'; ctx.lineWidth = 1.5; ctx.stroke();
            });

            // Center Arc Core
            ctx.fillStyle = (state === 'ARRIVED') ? '#ff1744' : '#0284c7';
            ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();

            if (state === 'ARRIVED') {
                drone.strobeFlash = !drone.strobeFlash;
                if (drone.strobeFlash) {
                    ctx.fillStyle = 'rgba(255, 23, 68, 0.9)';
                    ctx.beginPath(); ctx.arc(0, 0, 18, 0, Math.PI * 2); ctx.fill();
                }
            }

            ctx.restore();

            ctx.font = 'bold 11px "Orbitron"';
            ctx.fillStyle = '#38bdf8';
            ctx.fillText('🚁 STARK-DRONE-01', dx - 65, dy - 20);

            requestAnimationFrame(drawJarvisRadar);
        }

        // ==============================================
        //  ECG & AUDIO OSCILLOSCOPES
        // ==============================================
        function drawOscilloscopes() {
            // ECG
            const ew = ecgCanvas.width;
            const eh = ecgCanvas.height;
            ecgCtx.fillStyle = '#02050b';
            ecgCtx.fillRect(0, 0, ew, eh);

            ecgCtx.strokeStyle = (state === 'NORMAL') ? '#00e676' : '#ff1744';
            ecgCtx.lineWidth = 2;
            ecgCtx.beginPath();
            ecgPhase += (state === 'NORMAL') ? 0.08 : 0.24;

            for (let x = 0; x < ew; x++) {
                const angle = (x / 18) + ecgPhase;
                let y = eh / 2;
                const p = Math.sin(angle);
                if (p > 0.82) y -= (p - 0.82) * eh * 1.8;
                else if (p < -0.82) y += eh * 0.45;
                if (x === 0) ecgCtx.moveTo(x, y);
                else ecgCtx.lineTo(x, y);
            }
            ecgCtx.stroke();

            // Audio Spectrum
            const aw = audioCanvas.width;
            const ah = audioCanvas.height;
            audioCtx.fillStyle = '#02050b';
            audioCtx.fillRect(0, 0, aw, ah);

            audioCtx.strokeStyle = (state === 'NORMAL') ? '#00e5ff' : '#ff1744';
            audioCtx.lineWidth = 2;
            audioCtx.beginPath();
            audioPhase += 0.15;

            const amp = (state === 'NORMAL') ? 5 : 20;
            for (let x = 0; x < aw; x += 4) {
                const hVal = Math.sin(x * 0.1 + audioPhase) * amp + (Math.random() * (state === 'NORMAL' ? 3 : 14));
                audioCtx.moveTo(x, (ah / 2) - hVal);
                audioCtx.lineTo(x, (ah / 2) + hVal);
            }
            audioCtx.stroke();

            requestAnimationFrame(drawOscilloscopes);
        }

        // ==============================================
        //  MISSION CONTROL & ANIME.JS SEQUENCES
        // ==============================================
        async function triggerAmbush() {
            playJarvisBeep(1200, 0.15, 'sawtooth');
            seq++;
            state = 'ATTACK';
            currentIncidentId = "INC-" + Math.random().toString(36).substring(2, 8).toUpperCase();

            // Alert Flashing
            anime({
                targets: '#hudDefenseStatus',
                backgroundColor: ['rgba(255, 23, 68, 0.1)', 'rgba(255, 23, 68, 0.4)'],
                duration: 600,
                direction: 'alternate',
                loop: 4,
                easing: 'easeInOutQuad'
            });
            document.getElementById('hudDefenseStatus').innerText = '🚨 CODE RED // STEALTH SOS ACTIVE';

            // Anime.js Metric Surge
            const hrObj = { val: 72 };
            anime({
                targets: hrObj,
                val: 168,
                round: 1,
                duration: 1200,
                easing: 'easeOutExpo',
                update: () => {
                    document.getElementById('valHR').innerText = hrObj.val;
                }
            });

            const hrvObj = { val: 48.2 };
            anime({
                targets: hrvObj,
                val: 3.2,
                round: 10,
                duration: 1200,
                easing: 'easeOutExpo',
                update: () => {
                    document.getElementById('valHRV').innerText = hrvObj.val.toFixed(1);
                }
            });

            document.getElementById('cardHR').className = 'holo-card danger';
            document.getElementById('cardHRV').className = 'holo-card danger';
            document.getElementById('cardAcoustic').className = 'holo-card danger';
            document.getElementById('badgeBioStatus').innerText = 'PANIC ATTACK';
            document.getElementById('badgeBioStatus').style.color = 'var(--jarvis-red)';

            document.getElementById('valAcoustic').innerText = 'HUMAN_SCREAM_PANIC';
            document.getElementById('badgeAudioStatus').innerText = 'SCREAM DETECTED';
            document.getElementById('badgeAudioStatus').style.color = 'var(--jarvis-red)';
            document.getElementById('valConf').innerText = '96.8%';
            document.getElementById('valConf').style.color = 'var(--jarvis-red)';

            document.getElementById('valScreen').innerText = 'BLACKOUT (STEALTH MODE ACTIVE)';
            document.getElementById('valScreen').style.color = 'var(--jarvis-red)';
            document.getElementById('valUplink').innerText = 'ENCRYPTED MQTT (QoS 2 ACTIVE)';
            document.getElementById('valUplink').style.color = 'var(--jarvis-cyan)';

            document.getElementById('hudTargetStatus').innerText = 'THREAT_CONVERGENCE_DETECTED';
            document.getElementById('hudTargetStatus').style.color = 'var(--jarvis-red)';
            document.getElementById('hudFlightStatus').innerText = 'HIGH_SPEED_INTERCEPT';
            document.getElementById('badgeDroneStatus').innerText = 'DRONE DISPATCHED';
            document.getElementById('badgeDroneStatus').style.color = 'var(--jarvis-gold)';

            // Drone Flight Animation Across Radar
            drone.active = true;
            drone.x = tower.x;
            drone.y = tower.y;

            const etaObj = { eta: 45.0 };
            anime({
                targets: etaObj,
                eta: 0.0,
                round: 10,
                duration: 4000,
                easing: 'linear',
                update: () => {
                    document.getElementById('valETA').innerHTML = `${etaObj.eta.toFixed(1)} <span style="font-size:0.75rem;">sec</span>`;
                    document.getElementById('valSpeedAlt').innerText = `80 km/h | 65m AGL`;
                }
            });

            anime({
                targets: drone,
                x: guy.x,
                y: guy.y,
                duration: 4000,
                easing: 'easeInOutQuad',
                complete: () => {
                    state = 'ARRIVED';
                    playJarvisBeep(600, 0.2, 'square');
                    document.getElementById('hudFlightStatus').innerText = 'ON_SCENE_LOITERING';
                    document.getElementById('badgeDroneStatus').innerText = 'ON SCENE LOITERING';
                    document.getElementById('badgeDroneStatus').style.color = 'var(--jarvis-green)';
                    document.getElementById('valSpeedAlt').innerText = `0 km/h | 30m AGL (LOITER)`;
                    document.getElementById('valDeterrence').innerText = `HIGH-LUMEN STROBES & SIREN ON`;
                }
            });

            // Post to Server
            const payload = {
                incident_id: currentIncidentId,
                user_id: "CITIZEN-PRIYA-NCR-771",
                sequence_number: seq,
                gps: { latitude: 28.6289, longitude: 77.2065, altitude_m: 12.0 },
                heart_rate_bpm: 168.0,
                hrv_rmssd: 3.2,
                acoustic_category: "HUMAN_SCREAM_PANIC",
                acoustic_confidence: 0.968,
                threat_level: "CRITICAL",
                trigger_type: "ZERO_CLICK_MULTI_FACTOR_DANGER",
                stealth_mode_active: true,
                battery_level_pct: 91.0
            };

            await fetch("/api/v1/sos/trigger", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            }).then(r => r.json()).then(data => {
                if(data.block_hash) addLedgerEntry(data.block_index, data.incident_id, data.block_hash, "000000...");
            });
        }

        async function trigger3sButton() {
            triggerAmbush();
            document.getElementById('hudDefenseStatus').innerText = '⚡ 3s HARDWARE OVERRIDE TRIGGERED';
        }

        function resetSystem() {
            playJarvisBeep(440, 0.08, 'sine');
            state = 'NORMAL';
            drone.active = false;
            drone.x = tower.x;
            drone.y = tower.y;

            document.getElementById('hudDefenseStatus').innerText = 'CLEARANCE: LEVEL-5 // ARMED';
            document.getElementById('hudDefenseStatus').style.color = 'var(--jarvis-red)';
            document.getElementById('hudDefenseStatus').style.borderColor = 'var(--jarvis-red)';
            document.getElementById('hudDefenseStatus').style.background = 'rgba(255, 23, 68, 0.1)';

            document.getElementById('valHR').innerText = '72';
            document.getElementById('valHRV').innerText = '48.2';
            document.getElementById('cardHR').className = 'holo-card';
            document.getElementById('cardHRV').className = 'holo-card';
            document.getElementById('cardAcoustic').className = 'holo-card';

            document.getElementById('badgeBioStatus').innerText = 'NOMINAL';
            document.getElementById('badgeBioStatus').style.color = 'var(--jarvis-green)';

            document.getElementById('valAcoustic').innerText = 'AMBIENT_NORMAL';
            document.getElementById('badgeAudioStatus').innerText = 'LISTENING';
            document.getElementById('badgeAudioStatus').style.color = 'var(--jarvis-cyan)';
            document.getElementById('valConf').innerText = '94.8%';
            document.getElementById('valConf').style.color = 'var(--jarvis-green)';

            document.getElementById('valScreen').innerText = 'UNLOCKED (NORMAL)';
            document.getElementById('valScreen').style.color = 'var(--jarvis-green)';
            document.getElementById('valUplink').innerText = 'STANDBY (0 B/s)';
            document.getElementById('valUplink').style.color = 'var(--text-dim)';

            document.getElementById('hudTargetStatus').innerText = 'SURVEILLANCE_ACTIVE';
            document.getElementById('hudTargetStatus').style.color = 'var(--jarvis-green)';
            document.getElementById('hudFlightStatus').innerText = 'IDLE_IN_DOCK';
            document.getElementById('badgeDroneStatus').innerText = 'DOCKED READY';
            document.getElementById('badgeDroneStatus').style.color = 'var(--jarvis-cyan)';
            document.getElementById('valETA').innerHTML = `0.0 <span style="font-size:0.75rem;">sec</span>`;
            document.getElementById('valSpeedAlt').innerText = `0 km/h | 0m AGL`;
            document.getElementById('valDeterrence').innerText = `HIGH-LUMEN STROBES ARMED`;
        }

        async function verifyChain() {
            playJarvisBeep(980, 0.1, 'sine');
            if(!currentIncidentId) { alert("No incident selected."); return; }
            const res = await fetch(`/api/v1/incidents/${currentIncidentId}/evidence-ledger`).then(r => r.json());
            alert(`🔒 STARK CRYPTOGRAPHIC AUDIT REPORT:
• SHA-256 Ledger Chain Valid: ${res.chain_integrity_valid}
• Total Verified Blocks: ${res.block_count}
• Audit Message: ${res.audit_report}`);
        }

        window.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                e.preventDefault();
                triggerAmbush();
            } else if (e.key === 'r' || e.key === 'R') {
                resetSystem();
            } else if (e.key === 'v' || e.key === 'V') {
                verifyChain();
            }
        });

        // Initialize loops
        drawJarvisRadar();
        drawOscilloscopes();
    </script>
</body>
</html>
"""


@app.get("/", response_class=HTMLResponse)
def serve_dashboard():
    base_dir = Path(__file__).resolve().parent.parent
    template_path = base_dir / "templates" / "index.html"
    if template_path.exists():
        try:
            with open(template_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            pass
    return EMBEDDED_HTML_DASHBOARD
