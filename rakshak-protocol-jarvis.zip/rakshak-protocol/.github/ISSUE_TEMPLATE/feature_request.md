---
name: Feature Request
about: Suggest an idea or enhancement for the Rakshak Protocol
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is.

**Describe the Solution You'd Like**
A clear and concise description of what you want to happen.

**Hardware / Protocol Considerations**
Describe any impact on edge power consumption, MQTT bandwidth, or MAVLink drone telemetry.
