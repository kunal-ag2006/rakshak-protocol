---
name: Bug Report
about: Create a report to help us improve Rakshak Protocol
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the Bug**
A clear and concise description of what the bug is.

**Component Affected**
- [ ] Edge Device / TinyML Acoustic Engine
- [ ] Biometric Triage (PPG / HRV)
- [ ] Hardware Interrupt Handler
- [ ] Cryptographic Evidence Vault
- [ ] Drone Routing / Spatial Allocation
- [ ] FastAPI Backend / WebSocket Stream
- [ ] Emergency Operations Center (EOC) Dashboard

**To Reproduce**
Steps to reproduce the behavior:
1. Run `...`
2. Trigger telemetry frame with `...`
3. See error

**Expected Behavior**
A clear and concise description of what you expected to happen.

**Environment (please complete the following information):**
 - OS: [e.g. Ubuntu 22.04 / Android 14 / FreeRTOS]
 - Python Version: [e.g. 3.11.2]
 - Hardware: [e.g. ESP32-S3, WearOS, Linux Server]
